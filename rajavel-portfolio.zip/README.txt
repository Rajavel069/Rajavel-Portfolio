RAJAVEL PORTFOLIO

GitHub Pages:
1. Create a repository.
2. Upload index.html and the assets folder.
3. Settings -> Pages -> Deploy from a branch -> main -> / (root).
4. Open the published GitHub Pages URL.
